import machine
from machine import Pin,PWM
import time

echo = Pin(18,Pin.IN)
trig = Pin(5,Pin.OUT)
buzzer = Pin(21,Pin.OUT)
buzzer_pwn = PWM(buzzer)


while True:
    trig.value(0)
    time.sleep(0.5)
    trig.value(1)
    time.sleep(0.5)
    trig.value(0)
    x = machine.time_pulse_us(echo,1)
    distance = (0.034 * x) / 2
    tran_dis = '%.2f' %(distance)
    print(f"distance : {tran_dis} cm")
    if distance <= 50:
        buzzer_pwn.freq(500)
        time.sleep(1)
        buzzer_pwn.duty(100)       
        time.sleep(1)
        buzzer_pwn.duty(0)
        time.sleep(1)
    else:
        buzzer_pwn.duty(0)